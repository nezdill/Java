package dillard4;

public class AsciiRan {

	public static void main(String[] args) {
		
		int num = (int) (48 + Math.random() * 75);
		System.out.println("The integer is " + num);
		char ch = (char) num;
		
		if (num <= 57) {
		System.out.println("That is a digit");
		}
		else if (num <=64) {
			System.out.println("That is a symbol");
		}
		else if (num <=90) {
			System.out.println("That is a capitalized letter ");
		}
		else if (num <=96) {
			System.out.println("That is a symbol");
		}
		else  {
			System.out.println("That is a lowercase letter ");
		
		}
		
		
		System.out.println("The ASCII Character is " + ch);
		
	}

}
