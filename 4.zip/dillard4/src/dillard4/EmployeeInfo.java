package dillard4;

public class EmployeeInfo {

	public static void main(String[] args) {

		String name = "William";
		char office = 'B';
		int age = 25;
		double pay = 18.50;

		System.out.printf("%.4s is %d years old. \n", name, age);
		System.out.printf("He is in office %c \n", office);
		System.out.printf("In a 40-hour week, his pay is $%.2f", 40 * pay);

	}

}
