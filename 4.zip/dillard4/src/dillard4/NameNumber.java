package dillard4;

import java.util.Scanner;

public class NameNumber {

	public static void main(String[] args) {
	    Scanner input = new Scanner(System.in);
		System.out.print("Enter a three word phrase as one String: ");
		String s = input.nextLine();
		int sp1 = s.indexOf(" ");
		int sp2 = s.lastIndexOf(" ");
		String middle = s.substring(sp1 + 1, sp2);
		System.out.println("The number of charaters in the phrase " + s.length());
		System.out.println("The number of characters in the middle word " +middle);
		System.out.println("The Final word in all upper case is "+ s.substring(sp2 +1).toUpperCase() );
	}

}
