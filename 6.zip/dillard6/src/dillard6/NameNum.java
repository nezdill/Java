package dillard6;
import java.util.Scanner;

public class NameNum {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter your name, please ");
		String name = input.nextLine();
		//int len = stringer(name);
		//System.out.println("\nName length " + len);
		System.out.println("\nName length " + stringer(name));
	}
	public static int stringer(String str) {
		for(int i = str.length()-1; i >= 0; i--) {
			System.out.print(str.charAt(i));
		}
		return str.length();
	}

}
