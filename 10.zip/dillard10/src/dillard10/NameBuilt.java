package dillard10;

public class NameBuilt {

	public static void main(String[] args) {
		StringBuilder name = new StringBuilder();
		name.append("Arnez ");
		name.append("Dillard");
		System.out.println(name.toString());
		name.insert(name.indexOf(" "), " D");
		System.out.println(name.toString());
		name.replace(name.indexOf(" "), name.lastIndexOf(" "), "");
		name.reverse();
		System.out.println(name.toString());

	}

}
