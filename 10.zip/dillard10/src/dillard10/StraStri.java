package dillard10;

public class StraStri {

	public static void main(String[] args) {
		String name = "#J$a%$v#a*%w#@a$s*m#@a$$d%e*b$#y*#J%a@#m%$e$s*$#G%%o#s#@li%#n%g%$#";
		
		name = name.replaceAll("\\@", "");
		name = name.replaceAll("\\#", "");
		name = name.replaceAll("\\$", "");
		name = name.replaceAll("\\%", "");
		String [] pass = name.split("\\*");
		for(String a: pass) {
			System.out.print(a + " ");
		}
	}

}
