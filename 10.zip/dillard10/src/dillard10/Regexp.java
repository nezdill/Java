package dillard10;

import java.util.Scanner;

public class Regexp {

	public static void main(String[] args) {
		
		System.out.println("Enter your phone in format ###.###-#####");
		Scanner input = new Scanner(System.in);
		String ph = input.nextLine();
		
		if(ph.matches("\\d{3}\\.\\d{3}-\\d{4}")) {
			System.out.println("Good input");
		}
			else {
				System.out.println("Bad input");
			}
		}
	}


