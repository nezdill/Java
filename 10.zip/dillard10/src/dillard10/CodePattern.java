package dillard10;
import java.util.Scanner;

public class CodePattern {

	public static void main(String[] args) {
		
		System.out.println("Enter the code pattern ");
		Scanner input = new Scanner(System.in);
		String password = input.nextLine();
		input.close();
		if(password.matches("[A-Z][a-z][A-Z][a-z]\\d{4}[a-z]{2,3}[A-Z]{2}\\d")){
			System.out.printf("Yes, %s matches the pattern " , password);
		}else {
			System.out.println("The password didn't match ");
		}
	}

}
