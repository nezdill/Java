package dillard10;
import java.util.Scanner;

public class hexaDec {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string holding a hexadecimal interger less than 256 ");
		String hex = input.nextLine();
		int num = Integer.parseInt(hex,16);
		System.out.println("The hex number is " + num);
		String binary = Integer.toBinaryString(num);
		System.out.println("As a binary number it's " + binary);
		System.out.println("That binary number back to base ten is " +Integer.parseInt(binary,2));
	}

}
