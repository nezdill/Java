package dillard6;
import java.util.Scanner;

public class OverAdd {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter two or three intergers, please ");
		int num = input.nextInt();
		int num2 = input.nextInt();
		int num3 = input.nextInt();
		value(num, num2, num3);
		value(num, num2);
	}
	public static void value(int num, int num2) {
		int total = 0;
		total = num + num2;
		System.out.println("\nThe total of your two intergers " + num + " " + num2 + " is "  + total);
		
		return;
		
	}
	
	public static void value(int num, int num2, int num3) {
		int total = 0;
		total = num + num2 + num3;
		
		System.out.println("The total of your three intergers " + num + " "+ num2 + " "+ " " + num3 + " is " + total);
	
		return;
	}
}
