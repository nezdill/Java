package dillard6;

import java.util.Scanner;

public class PractMethod {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter two doubles ");
		double num = input.nextDouble();
		double num2 = input.nextDouble();
		totaldiff(num, num2);
		double result = num * num2;
		System.out.println(num + " times " + num2 + " = " + result);
		quotient(num, num2);
	}

	public static void totaldiff(double num, double num2) {
		double sum = 0;
		sum = num + num2;
		System.out.println("The total of " + num + " and " + num2 + " is " + sum);
		double differ = 0;
		if (num2 > num) {

			double differ2 = 0;
			differ2 = num2 - num;
			System.out.println("The positive difference between " + num + " and " + num2 + " is " + differ2);

		} else {
			differ = num - num2;
			System.out.println("The positive difference between " + num + " and " + num2 + " is " + differ);
		}
		return;

	}
	
	
	

	public static int quotient(double num, double num2) {
		double answer = 0;
		if (num2 > num) {
			answer = num2 / num;
			System.out.println(num2 + " divided by " + num + " = " + answer);
		} else {
			answer = num / num2;
			System.out.println(num + " divided by " + num2 + " = " + answer);
		}
		return (int) answer;

	}
}
