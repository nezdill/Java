package dillard7and11;

import java.util.Arrays;

public class Eight {

	public static void main(String[] args) {
		int[] myList = new int[8];
		for(int i = 0; i < myList.length; i++) {
			myList[i] = 50 + (int)(Math.random()* 51);
		}
		int[] smallestLargest = sortArrayAndReturnSmallestLargest(myList);
		System.out.println("The lowest element is ");
		System.out.println((smallestLargest[0]));
		System.out.println("The largest element is ");
		System.out.println((smallestLargest[1]));
		System.out.println("Here is the array");
		int oddNum = 0;
		int evenNum = 0;
		int total = 0;
		int totaltwo = 0;
		for(int i : myList) {
			System.out.print(i + " ");
			if(i % 2 == 0) {
				oddNum++;
			}
			else {
				evenNum++;
			}
		}
		total += evenNum;
		totaltwo += oddNum;
		System.out.println("\nEvens: " + total);
		System.out.println("Odds: " + totaltwo);
		System.out.println();
		System.out.println("Total: "+ total);
	}

public static int[] sortArrayAndReturnSmallestLargest(int[] myList) {
	int[] smallestLargest = new int[2];
	Arrays.sort(myList);
	smallestLargest[0] = myList[0];
	smallestLargest[1] = myList[7];
	return smallestLargest;
}
}