package dillard7and11;

import java.util.ArrayList;

public class FamList {

	public static void main(String[] args) {

		ArrayList<String> list = new ArrayList<>();
		list.add("Lionel Messi");
		list.add("Drake");
		list.add("Adele");
		list.add("Dwayne Johnson");
		list.add("Beyonce");
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		pass(list);
	}

	public static void pass(ArrayList<String> args) {
		args.add(2, "Taylor Swift");
		args.remove(4);
		for (String name : args) {
			System.out.print(" * " + name);
		}
	}
}
