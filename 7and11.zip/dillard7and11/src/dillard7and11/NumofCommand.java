package dillard7and11;

public class NumofCommand {

	public static void main(String[] args) {
		
		int[] num = new int [args.length];
		for(int i = 0; i < args.length; i++) {
			num [i] = Integer.parseInt(args[i]);
			System.out.print(num[i]+ " ");
		}
		//sumInts(1,2,3,4,5);
		int total = sumInts(num);
		System.out.println();
		System.out.println("Sum is " + total);
		
	}
	public static int sumInts(int... num) {
		int total = 0;
		for(int nom: num) {
			total += nom;
		}
		return total;


}

}
