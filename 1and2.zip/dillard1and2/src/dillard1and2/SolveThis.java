//Arnez Dillard 2339395

package dillard1and2;

public class SolveThis {

	public static void main(String[] args) {
		double nez = (12.25 / 3.5 + 2.5) / (6.5 + 4.5 * 3); //assigning the expression to a varible
		System.out.println("This is " + nez +" times worse"); // Printing the results
	}

}
