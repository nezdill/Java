//Arnez Dillard 2339395

package dillard1and2; // name of package

public class NameLine {

	public static void main(String[] args) {
		System.out.println("An Eclipse workspace folder holds Java projects");	//Printing out  each line of code to be displayed
		System.out.println("in folder with the same names as the projects");
		System.out.println("and zips of these folders are submitted for grades.");

	}

}
