package dillard9;

public class TestCar {

	public static void main(String[] args) {
		Car car = new Car("Lamborghini", "Aventador", 2015, 405000.0, "yellow");
		Car honda = new Car("Honda", "Odyssey", 2015, 33560.0, "Cherry");
		Car dodge = new Car();
		dodge.setMake("Dodge");
		dodge.setModel("Hellcat");
		dodge.setYear(2016);
		dodge.setPrice(76500.0);
		dodge.setColor("Orange");
		Car [] newArray = {car, honda, dodge};
		double total = evaluateCars(newArray);
		System.out.printf("Your cars are worth $%,.2f", total);
		
	}
	public static double evaluateCars(Car [] args) {
		double total = 0;
		for(Car name: args) {
			total += name.getPrice();
			System.out.println(name.toString());
		}
		return total;
	}

}
