package week2.Dillard;

public abstract class Danio extends Fish  {
	
	public Danio(int zone) {
		super();
	}

	public int getOxygenConsumption() {
		return 12;
	}


	public String swim() {
		return "Danio darting";
	}

	}
