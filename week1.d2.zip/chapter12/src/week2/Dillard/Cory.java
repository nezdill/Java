package week2.Dillard;

public abstract class Cory extends Fish  {
	
	public Cory(int zone) {
		super();
	}

	public int getOxygenConsumption() {
		
		return 12;
	}


	public String swim() {
		
		return "Cory just hanging out";
	}

	}