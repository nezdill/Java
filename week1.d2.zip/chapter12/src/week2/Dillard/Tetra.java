package week2.Dillard;

public abstract class Tetra extends Fish  {
	
	public Tetra(int zone) {
		super();
	}

	public int getOxygenConsumption() {
		return 10;
	}


	public String swim() {
		
		return "Tetra gliding";
	}

	}