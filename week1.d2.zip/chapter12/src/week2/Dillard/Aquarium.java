package week2.Dillard;

import java.util.ArrayList;

public abstract class Aquarium extends Fish {
	
	private ArrayList <Fish> life = new ArrayList<>();
	
	private int capacity;
	
	public int Aquarium(int width, int length) {
		this.capacity = width * length;
		return this.capacity;
	}
	
	public boolean add(Fish o) {
		
		return false;
		
	}
	
	public ArrayList<Fish> getFish() {
		return life;	
	}
	
	public int getNumberOfFish() {
		
		return capacity;
	}

}
