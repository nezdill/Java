package week2.Dillard;

public abstract class Fish {
	
private int zone;

/*int top = 1;
int middle = 2;
int bottom = 3;
*/

public  int Fish (int zone) {
	int top = 1;
	int middle = 2;
	int bottom = 3;
	
	return zone;
}

public int getZone() {	
	return zone;
}

public abstract int getOxygenConsumption();

public abstract String swim();

public abstract class ComparableFish extends Fish
implements Comparable<ComparableFish>{

	@Override
	public int compareTo(ComparableFish o) {
		if(getZone() > o.getZone())
			return 1;
		else if(getZone() < o.getZone())
		return -1;
		else
			return 0;
	}

/*	@Override
	public int getOxygenConsumption() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String swim() {
		// TODO Auto-generated method stub
		return null;
	}
*/

}

}
