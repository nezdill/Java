package dillard3;

public class Inclusive {

	public static void main(String[] args) {
		//random num from 1 -12
		int num = 1 + (int)(Math.random() *12);
		System.out.println(num);
		
		if (num < 7)
			System.out.println("This number is less than 7");
		else if (num > 7)
			System.out.println("This number is greater than 7");
		else 
			System.out.println("This number is equal to 7");

	}

}
