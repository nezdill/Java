package dillard3;

import java.util.Scanner;

public class AcmeShirt2 {

	public static void main(String[] args) {
		System.out.println("Enter an order quantity ");
		Scanner input = new Scanner(System.in);

		int quantity = input.nextInt();
		double purchPrice = 19.95 * quantity;
		double discount;

		if (quantity >= 12) {
			discount = .40;

		} else if (quantity >= 8) {
			discount = .30;

		} else if (quantity >= 5) {
			discount = .20;

		} else if (quantity >= 3) {
			discount = .10;

		} else {

			discount = 0;

		}
		double finalCost = purchPrice * (1 - discount);
		System.out.println("PLease pay $" + finalCost);
	}

}
