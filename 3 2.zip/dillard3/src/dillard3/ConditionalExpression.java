package dillard3;

import java.util.Scanner;

public class ConditionalExpression {

	public static void main(String[] args) {
		System.out.println("Enter an odd multiple of 17 that is under 200 ");
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
		
		

	
	System.out.println((num < 200 && num % 17 == 0) ? "Acceptable" : "Unacceptable");
	


	}
	}