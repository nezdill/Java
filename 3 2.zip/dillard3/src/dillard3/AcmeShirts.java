package dillard3;
import java.util.Scanner;
public class AcmeShirts {

	public static void main(String[] args) {
		
		System.out.println("Enter an order quantity ");
		
		Scanner input = new Scanner(System.in);

		int quantity = input.nextInt();
		double purchPrice = 19.95 * quantity;
		double discount;

		switch (quantity) {
		case 3: case 4:
			discount = .10;
			double finalCost = purchPrice * (1 - discount);
			System.out.println("PLease pay $" + finalCost);
		break;
		case 5: case 6: case 7:
			discount = .20;
			double finalCost5 = purchPrice * (1 - discount);
			System.out.println("PLease pay $" + finalCost5);
		break;
		case 8: 
			discount = .30;
			double finalCost8 = purchPrice * (1 - discount);
			System.out.println("PLease pay $" + finalCost8);
			break;
		case 12:  
			discount = .40;
			double finalCost2 = purchPrice * (1 - discount);
			System.out.println("PLease pay $" + finalCost2);
			break;
		default:	System.out.println("Error invalid satus");
		}	
		
	}

}
