package dillard5;

import java.util.Scanner;

public class TestTotal {

	public static void main(String[] args) {
		int data;
		int sum = 0;
		double total = 0;
		int count = -1;
		
		
		Scanner input = new Scanner(System.in);
		
		do {
			System.out.println("Enter an integer or 0 to quit: ");
			data = input.nextInt();
			sum += data;
			count++;
			
		} while(data != 0);
		
		total = sum/count;
		System.out.println("The total of those " + count + " numbers are "+ sum);
		System.out.printf("The average is %.3f", total); //three decimals
	}

}
