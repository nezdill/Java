package dillard5;

public class NumerOfMultiples {

	public static void main(String[] args) {

		int count = 200;
		int number = 300;
		int total = 0;
		int counter = 0;

		while (number >= count) {
			
			for (int col = 0; col < 6; col++) {
				if (number % 11 == 0 ^ number % 13 == 0) {
					System.out.print(number + "\t");
					counter++;
					total++;
					if (counter == 5) {
						System.out.print("\n");
						counter = 0;
					}
					
				}
				
				number--;
			}
			
		}
		System.out.println(total);
	}

}
