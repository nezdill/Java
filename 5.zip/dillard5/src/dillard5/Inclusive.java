package dillard5;

public class Inclusive {

	public static void main(String[] args) {

			
		for (int j = 33; j <= 126; j++) {

			if (j % 20 == 0) {
				System.out.println();
			}
			char ch = (char) j;
			System.out.print(ch +" "+" ");

		}

	}

}
