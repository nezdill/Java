package dillard5;

public class Circle {

	public static void main(String[] args) {

		for (int j = 1; j <= 7; j++) {	//number of rows
			for (int k = 6; k >= j; k--) {
				System.out.print(" ");	//k-- every time loop run
			}
			for (int i = 1; i <= j; i++) { //i++ every time the loop run o's print
				System.out.print("o");
			}
			System.out.println("");
		}

	}

}
