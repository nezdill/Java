package dillard5;

public class Roots {

	public static void main(String[] args) {

		System.out.println("N \t Sqt Root \tCube Root");
		for (double i = 0; i <= 100; i += 5) {

			System.out.print(i);

			double n = Math.sqrt(i);
			System.out.printf("\t" + "%.5f %n", n, Math.sqrt(n));
			double z = Math.cbrt(i);
			System.out.printf(" \t \t"+"%.5f %n", z, Math.cbrt(z));
		}

	}
}
