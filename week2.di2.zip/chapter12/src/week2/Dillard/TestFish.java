package week2.Dillard;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

public class TestFish {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aquarium a = new Aquarium(10,10);
        a.add( new Tetra() );  // 10
        a.add( new Cory() );   // 18
        a.add( new Danio() );  // 12
        a.add( new Tetra() );  // 10
        a.add( new Cory() );   // 18
        a.add( new Danio() );  // 12
        
        // this will sort by zone
		a.watch();
		
		ArrayList<Fish> list = a.getFish();
		
		// the first two: Danio
		Fish f = list.get(0);
		System.out.println(f);
		f = list.get(1);
		System.out.println(f);
		
		// next two:  Tetra
		f = list.get(2);
		System.out.println(f);
		f = list.get(3);
		System.out.println(f);
		
		// last two:  Cory
		f = list.get(4);
		System.out.println(f);
		f = list.get(5);
		System.out.println(f);
	}

}
