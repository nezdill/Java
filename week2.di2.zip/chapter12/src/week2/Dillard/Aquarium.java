package week2.Dillard;

import java.util.ArrayList;
import java.util.Collections;

public class Aquarium {

	private ArrayList<Fish> life = new ArrayList<>();

	private int capacity;

	public Aquarium(int width, int length) {
		this.capacity = width * length;
	}

	public boolean add(Fish o) {
		int totalOxConsump = 0;
		for (Fish i : life) {
			totalOxConsump += i.getOxygenConsumption();
		}
		if (o.getOxygenConsumption() + totalOxConsump >= capacity) {
			return false;
		} else {
			life.add(o);
			return true;
		}

	}

	public ArrayList<Fish> getFish() {
		return life;
	}

	public int getNumberOfFish() {

		return life.size();
	}
	
	public void empty() {
		life.clear();
	}

	public void watch() {
		java.util.Collections.sort(life);
		for(Fish o : life) {
			o.swim();
		}
	}
}
