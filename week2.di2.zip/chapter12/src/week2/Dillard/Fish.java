package week2.Dillard;

public abstract class Fish implements Comparable<Fish> {

	private int zone;

	/*
	 * int top = 1; int middle = 2; int bottom = 3;
	 */
	public Fish() {
		this.zone = 1;
	}

	public Fish(int zone) {
		this.zone = zone;
	}

	public int getZone() {
		return zone;
	}

	public abstract int getOxygenConsumption();

	public abstract String swim();

	@Override
	public int compareTo(Fish o) {
		if (getZone() > o.getZone())
			return 1;
		else if (getZone() < o.getZone())
			return -1;
		else
			return 0;
	}

	/*
	 * @Override public int getOxygenConsumption() { // TODO Auto-generated method
	 * stub return 0; }
	 * 
	 * @Override public String swim() { // TODO Auto-generated method stub return
	 * null; }
	 */

}
