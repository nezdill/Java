package week2.Dillard;

public class Cory extends Fish  {
	
	public Cory() {
		super(3);
	}

	public int getOxygenConsumption() {
		
		return 18;
	}


	public String swim() {
		
		return "Cory just hanging out";
	}

	}