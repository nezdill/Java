package week2.Dillard;

public class Tetra extends Fish  {
	
	public Tetra() {
		super(2);
	}

	public int getOxygenConsumption() {
		return 10;
	}


	public String swim() {
		
		return "Tetra gliding";
	}

	}