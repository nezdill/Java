package week2.Dillard;

public abstract class ComparableFish extends Fish implements Comparable<Fish>{
	
	private int zone;
	
	public ComparableFish(int zone) {
		this.zone = zone;
	}
	
	@Override
	public int compareTo(Fish o) {
		if (this.getZone() > o.getZone())
			return 1;
		else if (this.getZone() < o.getZone())
			return -1;
		else
			return 0;
	}

}
