package week2.Dillard;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class TestAquarium
{

	@Test
	public void tankCreation()
	{
		Aquarium a = new Aquarium(10,10);
		assertEquals(0, a.getFish().size());
		assertEquals(0, a.getNumberOfFish());
		
		// should have no effect
		a.empty();
		assertEquals(0, a.getFish().size());
		assertEquals(0, a.getNumberOfFish());
	}
	
	@Test
	public void createDanio()
	{
		Danio d = new Danio();
		assertEquals(12, d.getOxygenConsumption());
		assertEquals("Danio darting", d.swim());
		assertEquals(1,d.getZone());
	}
	
	@Test
	public void createTetra()
	{
		Tetra d = new Tetra();
		assertEquals(10, d.getOxygenConsumption());
		assertEquals("Tetra gliding", d.swim());
		assertEquals(2,d.getZone());

	}
	
	@Test
	public void createCory()
	{
		Cory d = new Cory();
		assertEquals(18, d.getOxygenConsumption());
		assertEquals("Cory just hanging out", d.swim());
		assertEquals(3,d.getZone());

	}
	
	
	@Test
	public void addFish()
	{
		Aquarium a = new Aquarium(10,10);
        a.add( new Tetra() );  // 10
        a.add( new Cory() );   // 18
        a.add( new Danio() );  // 12
        a.add( new Tetra() );  // 10

		assertEquals(4, a.getFish().size());
		assertEquals(4, a.getNumberOfFish());
	}
	
	@Test
	public void addCapacity()
	{
		Aquarium a = new Aquarium(10,10);
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        
        boolean result = a.add( new Tetra() );  // 10

        assertTrue(result);
		assertEquals(10, a.getFish().size());
		assertEquals(10, a.getNumberOfFish());
	}
	
	@Test
	public void addOverCapacity()
	{
		Aquarium a = new Aquarium(10,10);
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10
        a.add( new Tetra() );  // 10

        boolean result = a.add( new Tetra() );  // 10

        assertFalse(result);

	}
	
	@Test
	public void addEmpty()
	{
		Aquarium a = new Aquarium(10,10);
        a.add( new Tetra() );  // 10
        a.add( new Cory() );   // 18
        a.add( new Danio() );  // 12
        a.add( new Tetra() );  // 10

		assertEquals(4, a.getFish().size());
		assertEquals(4, a.getNumberOfFish());
		
		a.empty();
		assertEquals(0, a.getFish().size());
		assertEquals(0, a.getNumberOfFish());
	}
	
	@Test
	public void addWatch()
	{
		Aquarium a = new Aquarium(10,10);
        a.add( new Tetra() );  // 10
        a.add( new Cory() );   // 18
        a.add( new Danio() );  // 12
        a.add( new Tetra() );  // 10
        a.add( new Cory() );   // 18
        a.add( new Danio() );  // 12
        
        // this will sort by zone
		a.watch();
		
		ArrayList<Fish> list = a.getFish();
		
		// the first two: Danio
		Fish f = list.get(0);
		assertTrue(f instanceof Danio);
		f = list.get(1);
		assertTrue(f instanceof Danio);
		
		// next two:  Tetra
		f = list.get(2);
		assertTrue(f instanceof Tetra);
		f = list.get(3);
		assertTrue(f instanceof Tetra);
		
		// last two:  Cory
		f = list.get(4);
		assertTrue(f instanceof Cory);
		f = list.get(5);
		assertTrue(f instanceof Cory);
	}
}
